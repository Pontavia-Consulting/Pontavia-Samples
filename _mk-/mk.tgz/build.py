#!/usr/bin/env python3
"""Concept mockup builder.
build_concept(prospect: dict) -> dict   (writes /root/concepts/<prospect_id>/ ...)
Pipeline: read the business's own home page -> pick archetype/palette -> write grounded copy (local Ollama,
falls back to safe templates) -> render the one-page concept -> screenshot -> watermarked showcase composite.
No paid APIs. Nothing here sends anything."""
import os, re, io, json, base64, hashlib, time, datetime, html as htmllib, urllib.request, urllib.robotparser
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader, select_autoescape
import art

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_ROOT = os.environ.get('CONCEPT_DIR', '/root/concepts')
OLLAMA = os.environ.get('OLLAMA_URL', 'http://10.0.1.199:11434')
MODEL = os.environ.get('CONCEPT_MODEL', 'qwen2.5:7b')
UA = 'Mozilla/5.0 (compatible; PontaviaConceptBot/1.0; +https://pontaviaconsulting.com)'
env = Environment(loader=FileSystemLoader(HERE), autoescape=select_autoescape(['html', 'j2']))


# ---------------------------------------------------------------- fetch & extract
def _get(url, timeout=12, cap=1_500_000):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'text/html,*/*;q=0.8'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read(cap)
        enc = r.headers.get_content_charset() or 'utf-8'
    return raw.decode(enc, 'replace')


def _allowed(url):
    try:
        u = urlparse(url)
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(f'{u.scheme}://{u.netloc}/robots.txt')
        rp.parse(_get(f'{u.scheme}://{u.netloc}/robots.txt', 8, 100_000).splitlines())
        return rp.can_fetch(UA, url)
    except Exception:
        return True   # no robots.txt reachable -> nothing disallowing us


PHONE = re.compile(r'(?:\+?1[\s.\-]?)?\(?([2-9]\d{2})\)?[\s.\-]?(\d{3})[\s.\-]?(\d{4})')
ADDR = re.compile(r'\d{1,6}\s+[A-Za-z0-9 .\-#]{3,40},?\s+[A-Za-z .]{3,30},?\s+FL\.?\s+\d{5}')
SELLS = ('add to cart', 'add to bag', 'woocommerce', 'shopify', 'checkout', '/cart', '/product')


def extract(url):
    info = dict(ok=False, title='', desc='', headings=[], nav=[], phone='', address='', text='', sells_online=False, site_name='')
    if not url:
        return info
    if not _allowed(url):
        info['blocked'] = True
        return info
    try:
        raw = _get(url)
    except Exception as e:
        info['error'] = str(e)[:120]
        return info
    soup = BeautifulSoup(raw, 'lxml')
    low = raw.lower()
    info['sells_online'] = any(k in low for k in SELLS)
    info['title'] = (soup.title.string or '').strip() if soup.title else ''
    m = soup.find('meta', attrs={'name': 'description'}) or soup.find('meta', attrs={'property': 'og:description'})
    info['desc'] = (m.get('content') or '').strip() if m else ''
    s = soup.find('meta', attrs={'property': 'og:site_name'})
    info['site_name'] = (s.get('content') or '').strip() if s else ''
    for t in soup(['script', 'style', 'noscript', 'svg', 'template']):
        t.decompose()
    seen = []
    for h in soup.find_all(['h1', 'h2', 'h3']):
        t = re.sub(r'\s+', ' ', h.get_text(' ', strip=True))
        if 3 < len(t) < 90 and t.lower() not in [x.lower() for x in seen]:
            seen.append(t)
    info['headings'] = seen[:14]
    nav = []
    for a in soup.select('nav a, header a'):
        t = re.sub(r'\s+', ' ', a.get_text(' ', strip=True))
        if 2 < len(t) < 28 and t.lower() not in [x.lower() for x in nav]:
            nav.append(t)
    info['nav'] = nav[:12]
    tel = soup.select_one('a[href^="tel:"]')
    text = re.sub(r'\s+', ' ', soup.get_text(' ', strip=True))
    if tel:
        d = re.sub(r'\D', '', tel['href'])[-10:]
        if len(d) == 10:
            info['phone'] = f'({d[:3]}) {d[3:6]}-{d[6:]}'
    if not info['phone']:
        pm = PHONE.search(text)
        if pm:
            info['phone'] = f'({pm.group(1)}) {pm.group(2)}-{pm.group(3)}'
    am = ADDR.search(text)
    if am:
        info['address'] = am.group(0)
    info['text'] = text[:2500]
    info['ok'] = True
    return info


# ---------------------------------------------------------------- copy
BANNED = ['best', '#1', 'award', 'licensed', 'insured', 'certified', 'family-owned', 'family owned', 'years', 'guarantee',
          'free ', 'locally owned', 'trusted', 'leading', 'premier', 'top-rated', '24/7', 'since ', 'experts', 'expert ',
          'lowest', 'cheapest', 'number one', 'voted', 'rated', 'five-star', '5-star', 'testimonial', '%']

FALLBACK = {
 'food':   ('Made fresh,', 'served with care.', 'Come hungry. Order ahead, book a table, and find us in minutes.',
            ['Dine in', 'Takeout and online ordering', 'Catering', 'Specials and events'], 'Order now', 'See the menu'),
 'beauty': ('Look good.', 'Feel even better.', 'Book your next appointment in seconds and see our work before you walk in.',
            ['Appointments', 'Signature services', 'Packages and memberships', 'Gift cards'], 'Book now', 'See our work'),
 'trades': ('Done right.', 'On time.', 'Request a quote in a minute, and see exactly what we do and where we work.',
            ['Estimates and quotes', 'Repairs and service calls', 'New installations', 'Maintenance plans'], 'Get a quote', 'Our services'),
 'medical': ('Care that', 'feels personal.', 'Easy online booking, clear information, and a warm welcome from the first click.',
            ['New patient visits', 'Routine care', 'Specialty services', 'Patient resources'], 'Book a visit', 'Meet the team'),
 'professional': ('Clear advice,', 'confident decisions.', 'A polished online home for your practice, built to earn trust before the first call.',
            ['Consultations', 'Core services', 'Client resources', 'Ongoing support'], 'Book a consult', 'Our services'),
 'fitness': ('Show up.', 'Stand out.', 'Classes, schedules and sign-ups, all in one tap.',
            ['Group classes', 'Personal training', 'Memberships', 'Workshops and events'], 'Join today', 'View classes'),
 'outdoors': ('Rooted here,', 'growing with you.', 'Everything we offer, easy to browse, book and find.',
            ['Our products', 'Services', 'Seasonal specials', 'Classes and events'], 'Visit us', 'See what we offer'),
 'retail': ('Find something', 'you will love.', 'A bright, easy online storefront that shows off what you carry.',
            ['New arrivals', 'Customer favorites', 'Gift ideas', 'In-store events'], 'Shop now', 'Browse the shop'),
 'default': ('A better first', 'impression.', 'A fast, modern website that shows customers what you do and makes it easy to reach you.',
            ['Our services', 'How it works', 'Get a quote', 'Contact us'], 'Get in touch', 'Learn more'),
}
SERVICE_BLURB = {
 'food': 'A clear, mouth-watering section customers can read at a glance.',
 'beauty': 'Presented beautifully, with an easy way to book it.',
 'trades': 'Spelled out plainly so customers know what to ask for.',
 'medical': 'Explained in friendly, plain language.',
 'professional': 'Presented clearly so visitors know where to start.',
 'fitness': 'Easy to browse, with sign-up one tap away.',
 'outdoors': 'Shown with room to breathe and easy next steps.',
 'retail': 'Displayed with big, inviting visuals.',
 'default': 'Presented clearly so customers can find it fast.',
}


VARIANTS = ['Presented clearly, so customers can find it fast.', 'Easy to understand, with a clear next step.', 'Shown with confident, modern design.', 'Simple to explore on any phone.']


def clean_name(n):
    n = htmllib.unescape(n or '').strip()
    n = re.sub(r'\s+', ' ', n)
    if n.isupper() and len(n) > 4:
        n = n.title()
    return n


def initials(n):
    w = [x for x in re.findall(r"[A-Za-z0-9]+", n) if x.lower() not in ('the', 'and', 'of', 'llc', 'inc', 'co')]
    return ''.join(x[0] for x in w[:2]).upper() or 'P'


def ask_llm(name, arch, ctx):
    prompt = f"""You write website copy for a small local business named "{name}". Business type guess: {arch}.
Use ONLY facts found in the CONTEXT below. Never invent years in business, awards, prices, guarantees, licenses, statistics, reviews, staff names or claims. If the context is thin, stay general and warm.
Return JSON with exactly these keys:
 "headline_a": first part of a hero headline (2-4 words),
 "headline_em": the highlighted second part (2-4 words),
 "lede": one sentence, max 26 words, what they do and for whom,
 "eyebrow": max 5 words (like "Serving Ocala and Marion County"),
 "about_title": max 7 words,
 "about": 2 short sentences, max 55 words total,
 "services": array of 3 to 6 objects {{"title": max 4 words, "text": max 18 words}} based on what the business really offers,
 "products": array of up to 4 short names of things they actually sell (empty array if none),
 "cta1": max 3 words, "cta2": max 3 words.
CONTEXT:
Title: {ctx.get('title','')}
Description: {ctx.get('desc','')}
Headings: {'; '.join(ctx.get('headings',[]))}
Menu: {'; '.join(ctx.get('nav',[]))}
Page text: {ctx.get('text','')[:1400]}"""
    body = json.dumps({'model': MODEL, 'prompt': prompt, 'stream': False, 'format': 'json',
                       'options': {'temperature': 0.5, 'num_predict': 700, 'num_ctx': 3072}}).encode()
    req = urllib.request.Request(OLLAMA + '/api/generate', data=body, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=420) as r:
        return json.loads(json.loads(r.read())['response'])


def _ok_text(s, ctx_low, maxlen):
    s = re.sub(r'\s+', ' ', str(s or '')).strip()
    if not s or len(s) > maxlen:
        return None
    sl = s.lower()
    for b in BANNED:
        if b in sl and b not in ctx_low:
            return None
    for d in re.findall(r'\d+', s):
        if d not in ctx_low:
            return None
    return s


def make_copy(name, arch, ctx, use_llm=True):
    fb = FALLBACK[arch]
    ctx_low = (' '.join([ctx.get('title', ''), ctx.get('desc', ''), ' '.join(ctx.get('headings', [])), ctx.get('text', ''), name])).lower()
    raw = {}
    source = 'fallback'
    if use_llm and ctx.get('ok'):
        try:
            raw = ask_llm(name, arch, ctx)
            source = 'llm'
        except Exception as e:
            raw, source = {}, 'fallback (llm error: %s)' % str(e)[:80]
    c = {}
    c['h1_a'] = _ok_text(raw.get('headline_a'), ctx_low, 28) or fb[0]
    c['h1_em'] = _ok_text(raw.get('headline_em'), ctx_low, 28) or fb[1]
    c['lede'] = _ok_text(raw.get('lede'), ctx_low, 190) or fb[2]
    c['eyebrow'] = _ok_text(raw.get('eyebrow'), ctx_low, 44) or 'Serving our community'
    c['about_title'] = _ok_text(raw.get('about_title'), ctx_low, 54) or f'The people behind {name}'
    c['about'] = _ok_text(raw.get('about'), ctx_low, 380) or 'A website should feel like walking through your front door: welcoming, clear, and easy to find your way around. This concept shows how your business could look online.'
    c['cta1'] = _ok_text(raw.get('cta1'), ctx_low, 22) or fb[4]
    c['cta2'] = _ok_text(raw.get('cta2'), ctx_low, 22) or fb[5]
    services = []
    for s in (raw.get('services') or [])[:6]:
        if isinstance(s, dict):
            t = _ok_text(s.get('title'), ctx_low, 32)
            x = _ok_text(s.get('text'), ctx_low, 130)
            if t:
                services.append({'title': t, 'text': x or VARIANTS[len(services) % 4]})
    if len(services) < 3:
        services = [{'title': t, 'text': VARIANTS[i % 4]} for i, t in enumerate(fb[3][:4])]
    c['services'] = services
    prods = [p for p in (_ok_text(x, ctx_low, 30) for x in (raw.get('products') or [])[:4]) if p]
    c['products'] = prods
    c['source'] = source
    return c


# ---------------------------------------------------------------- render
def fonts_css():
    fd = os.path.join(HERE, 'fonts')
    def b64(f):
        return base64.b64encode(open(os.path.join(fd, f), 'rb').read()).decode()
    return ''.join([
        f"@font-face{{font-family:Lora;font-weight:400 700;font-style:normal;src:url(data:font/woff;base64,{b64('lora.woff')}) format('woff')}}",
        f"@font-face{{font-family:Lora;font-weight:400 700;font-style:italic;src:url(data:font/woff;base64,{b64('lora-italic.woff')}) format('woff')}}",
        f"@font-face{{font-family:Poppins;font-weight:400;src:url(data:font/woff;base64,{b64('poppins-400.woff')}) format('woff')}}",
        f"@font-face{{font-family:Poppins;font-weight:500;src:url(data:font/woff;base64,{b64('poppins-500.woff')}) format('woff')}}",
        f"@font-face{{font-family:Poppins;font-weight:600 700;src:url(data:font/woff;base64,{b64('poppins-700.woff')}) format('woff')}}",
    ])


def render_html(pr, ctx, arch, c):
    name = clean_name(pr.get('business_name'))
    seed = int(hashlib.sha1((pr.get('prospect_id') or name).encode()).hexdigest()[:8], 16)
    p = art.PALETTES[arch]
    icons = art.ARCH_ICONS.get(arch, art.SERVICE_ICONS)
    allic = icons + [i for i in art.SERVICE_ICONS if i not in icons]
    for i, s in enumerate(c['services']):
        s['icon'] = art.ICONS[allic[i % len(allic)]]
    ic = art.ICONS
    features = [
        dict(icon=ic['cal'], title='Online booking', text='Customers pick a time that works and you get the request instantly.', btn='Book an appointment'),
        dict(icon=ic['chat'], title='Live chat', text='Answer questions while visitors are still on the page.', btn='Start a chat'),
        dict(icon=ic['star'], title='Reviews that sell', text='Show off happy customers right where decisions are made.', btn='Read reviews'),
        dict(icon=ic['camera'], title='Photo gallery', text='A bold gallery of your work, fast on any phone.', btn='View the gallery'),
        dict(icon=ic['mail'], title='Email sign-up', text='Grow a list of customers you can reach any time.', btn='Join the list'),
        dict(icon=ic['card'], title='Online payments', text='Take deposits and payments securely, day or night.', btn='Pay online'),
    ]
    store = bool(ctx.get('sells_online'))
    pnames = c['products'] or ['Featured item', 'Customer favorite', 'New arrival', 'Seasonal pick', 'Gift idea', 'Bundle'][:3]
    products = [dict(name=n, art=art.product_art(seed + i)) for i, n in enumerate(pnames[:3] if len(pnames) >= 3 else pnames + ['Featured item'] * (3 - len(pnames)))]
    place = 'Ocala, Florida'
    city = (pr.get('city') or '').strip()
    if city:
        place = f'{city.title()}, Florida'
    if ctx.get('address'):
        place = ctx['address'].replace('  ', ' ')
    phone = pr.get('phone_display') or ctx.get('phone') or ''
    if not phone and pr.get('phone'):
        d = re.sub(r'\D', '', pr['phone'])[-10:]
        if len(d) == 10:
            phone = f'({d[:3]}) {d[3:6]}-{d[6:]}'
    return env.get_template('concept.html.j2').render(
        name=name, initials=initials(name), p=p, fonts_css=fonts_css(), ic=ic, place=place, phone=phone,
        h1_a=c['h1_a'], h1_em=c['h1_em'], lede=c['lede'], eyebrow=c['eyebrow'], cta1=c['cta1'], cta2=c['cta2'],
        services=c['services'], services_title='Everything you need, in one place.',
        services_sub='A clear look at what we do, so visitors know right away that they are in the right place.',
        features=features, store=store, products=products,
        about_title=c['about_title'], about=c['about'], year=datetime.date.today().year,
        art_hero=art.hero_art(seed), art_about=art.about_art(seed), art_map=art.map_art(seed)), name, seed


def shoot(html_path, out_dir, name, domain, arch):
    from playwright.sync_api import sync_playwright
    from PIL import Image
    p = art.PALETTES[arch]
    files = {}
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page(viewport={'width': 1440, 'height': 900})
        pg.goto('file://' + html_path)
        pg.wait_for_timeout(500)
        # desktop crops
        def box(sel):
            return pg.eval_on_selector(sel, 'e=>{const r=e.getBoundingClientRect();return [r.left,r.top+scrollY,r.width,r.height]}')
        hb = box('.hero')
        hero_h = int(min(hb[3] + 330, 1300))
        pg.screenshot(path=out_dir + '/hero.png', clip={'x': 0, 'y': 0, 'width': 1440, 'height': hero_h}, full_page=True)
        strip = []
        for sel, label, fn in (('#services', 'Services', 'sec_services.png'), ('#features', 'Online features', 'sec_features.png'),
                               ('#store' if pg.query_selector('#store') else '#about', 'Online store' if pg.query_selector('#store') else 'About', 'sec_third.png')):
            b = box(sel)
            pg.screenshot(path=f'{out_dir}/{fn}', clip={'x': 100, 'y': b[1] + 40, 'width': 1240, 'height': 800}, full_page=True)
            strip.append((f'{out_dir}/{fn}', label))
        pg.screenshot(path=out_dir + '/full.png', full_page=True)
        pg.close()
        pm = br.new_page(viewport={'width': 390, 'height': 844}, device_scale_factor=2)
        pm.goto('file://' + html_path)
        pm.wait_for_timeout(500)
        pm.screenshot(path=out_dir + '/mobile.png', clip={'x': 0, 'y': 0, 'width': 390, 'height': 900}, full_page=True)
        pm.close()
        # composite
        def du(path, w=None, q=88):
            im = Image.open(path).convert('RGB')
            if w and im.width > w:
                im = im.resize((w, int(im.height * w / im.width)), Image.LANCZOS)
            b = io.BytesIO()
            im.save(b, 'JPEG', quality=q)
            return 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
        sc = env.get_template('showcase.html.j2').render(
            p=p, fonts_css=fonts_css(), name=name, domain=domain or 'yourbusiness.com',
            hero=du(out_dir + '/hero.png', 2020), mobile=du(out_dir + '/mobile.png', 600),
            strip=[dict(src=du(f, 900), label=l) for f, l in strip])
        sp = out_dir + '/showcase.html'
        open(sp, 'w').write(sc)
        ps = br.new_page(viewport={'width': 1280, 'height': 900}, device_scale_factor=1.5)
        ps.goto('file://' + sp)
        ps.wait_for_timeout(500)
        ps.screenshot(path=out_dir + '/showcase.png', full_page=True)
        ps.close()
        br.close()
    im = Image.open(out_dir + '/showcase.png').convert('RGB')
    im.save(out_dir + '/showcase.jpg', 'JPEG', quality=88, optimize=True, progressive=True)
    return im.size


def build_concept(pr, use_llm=True):
    pid = re.sub(r'[^A-Za-z0-9_-]', '', pr.get('prospect_id') or '') or hashlib.sha1(json.dumps(pr, sort_keys=True).encode()).hexdigest()[:12]
    out_dir = os.path.join(OUT_ROOT, pid)
    os.makedirs(out_dir, exist_ok=True)
    t0 = time.time()
    name = clean_name(pr.get('business_name'))
    ctx = extract(pr.get('website') or '')
    arch = art.pick_archetype(' '.join([name, ctx.get('title', ''), ctx.get('desc', ''), ' '.join(ctx.get('headings', [])), ' '.join(ctx.get('nav', []))]))
    c = make_copy(name, arch, ctx, use_llm)
    html, name, seed = render_html(pr, ctx, arch, c)
    hp = out_dir + '/concept.html'
    open(hp, 'w').write(html)
    size = shoot(hp, out_dir, name, pr.get('domain') or urlparse(pr.get('website') or '').netloc, arch)
    meta = dict(prospect_id=pid, business_name=name, archetype=arch, copy_source=c['source'], sells_online=bool(ctx.get('sells_online')),
                site_read=bool(ctx.get('ok')), size=list(size), built_at=datetime.datetime.utcnow().isoformat() + 'Z',
                seconds=round(time.time() - t0, 1), copy={k: c[k] for k in ('h1_a', 'h1_em', 'lede', 'eyebrow', 'cta1', 'cta2', 'about_title', 'about', 'services', 'products')})
    for f in os.listdir(out_dir):
        if (f.endswith('.png') or f == 'showcase.html') and not os.environ.get('KEEP_PNG'):
            os.remove(os.path.join(out_dir, f))
    lite = open(hp).read()
    lite = re.sub(r'@font-face\{[^}]*\}', '', lite)
    open(hp, 'w').write(lite)
    for k in c['services']:
        k.pop('icon', None)
    meta['copy']['services'] = c['services']
    json.dump(meta, open(out_dir + '/meta.json', 'w'), indent=1)
    meta['dir'] = out_dir
    meta['showcase'] = out_dir + '/showcase.jpg'
    return meta


if __name__ == '__main__':
    import sys
    pr = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    print(json.dumps(build_concept(pr, use_llm=os.environ.get('NO_LLM') != '1'), indent=1))
