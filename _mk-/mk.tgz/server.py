#!/usr/bin/env python3
"""Concept builder service (LAN only).
  POST /build        body: prospect row JSON -> builds concept, returns meta JSON      (one build at a time)
  GET  /file/<pid>/<showcase.jpg|concept.html|meta.json>
  GET  /health
"""
import json, os, threading, re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import build

LOCK = threading.Lock()
ALLOWED = {'showcase.jpg': 'image/jpeg', 'concept.html': 'text/html', 'meta.json': 'application/json'}


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype='application/json'):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/health':
            return self._send(200, {'ok': True, 'busy': LOCK.locked()})
        m = re.fullmatch(r'/file/([A-Za-z0-9_-]+)/([a-z._]+)', self.path)
        if m and m.group(2) in ALLOWED:
            p = os.path.join(build.OUT_ROOT, m.group(1), m.group(2))
            if os.path.isfile(p):
                return self._send(200, open(p, 'rb').read(), ALLOWED[m.group(2)])
        self._send(404, {'error': 'not found'})

    def do_POST(self):
        if self.path != '/build':
            return self._send(404, {'error': 'not found'})
        try:
            n = int(self.headers.get('Content-Length') or 0)
            pr = json.loads(self.rfile.read(n) or b'{}')
            with LOCK:
                meta = build.build_concept(pr, use_llm=not pr.get('no_llm'))
            self._send(200, meta)
        except Exception as e:
            self._send(500, {'error': str(e)[:300]})

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 8102), H).serve_forever()
