"""Procedural art, icons and palettes for the concept builder. No external assets."""
import random

ICONS = {
 'arrow': '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
 'pin': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/></svg>',
 'pinfill': '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.8" fill="#fff"/></svg>',
 'phone': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>',
 'clock': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
 'star': '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.6l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.4l-5.9 3.3 1.3-6.6L2.5 9.5l6.6-.8z"/></svg>',
 'check': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" stroke-width="1.8"/><path d="M7.5 12.5l3 3 6-7"/></svg>',
 'lock': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
 'cal': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/></svg>',
 'chat': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.5A8 8 0 1 1 21 12z"/></svg>',
 'camera': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.6"/></svg>',
 'user': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/></svg>',
 'mail': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3.5 7l8.5 6 8.5-6"/></svg>',
 'card': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h4"/></svg>',
 'heart': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20s-8-4.9-8-10.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 8 2.5C20 15.1 12 20 12 20z"/></svg>',
 'bolt': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>',
 'shield': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>',
 'leaf': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19c0-9 5-14 15-14 0 10-5 15-14 15"/><path d="M5 19l8-8"/></svg>',
 'wrench': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 6.5a4 4 0 0 0 5 5L11 20a2.1 2.1 0 0 1-3-3l8.5-8.5"/><path d="M14.5 6.5a4 4 0 0 1 5-3l-2.5 2.5.5 2.5 2.5.5L22 6.5"/></svg>',
 'sparkle': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/></svg>',
}
SERVICE_ICONS = ['sparkle', 'heart', 'bolt', 'shield', 'leaf', 'wrench', 'camera', 'star']
ARCH_ICONS = {
 'trades': ['wrench', 'bolt', 'shield', 'clock', 'check', 'phone'],
 'medical': ['heart', 'shield', 'cal', 'user', 'sparkle', 'check'],
 'beauty': ['sparkle', 'heart', 'star', 'camera', 'cal', 'user'],
 'food': ['star', 'heart', 'leaf', 'cal', 'sparkle', 'pin'],
 'outdoors': ['leaf', 'heart', 'shield', 'sparkle', 'cal', 'star'],
}

# on = text color used on the dark hero. All palettes verified for contrast on bg1/bg2.
PALETTES = {
 'food':     dict(bg1='#2B1410', bg2='#5A281B', accent='#F0A93E', accent2='#E0603A', paper='#FCF7EF', wash='#F6EBDC', ink='#241410', muted='#6A5A52', on='#FFF3E4'),
 'beauty':   dict(bg1='#2A1B2E', bg2='#573260', accent='#F0BBA6', accent2='#CF8FC0', paper='#FCF6F5', wash='#F6E9EA', ink='#2A1C2C', muted='#6E5E70', on='#FFF1EE'),
 'trades':   dict(bg1='#0E2233', bg2='#1B4767', accent='#F7A928', accent2='#43A9DB', paper='#F4F7FA', wash='#E5EDF4', ink='#0F1D2A', muted='#4F6070', on='#EAF3FA'),
 'medical':  dict(bg1='#0B3A3F', bg2='#16666B', accent='#62D6C6', accent2='#8DB9F7', paper='#F2F9F8', wash='#E0F0EE', ink='#0E2A2D', muted='#4C6769', on='#E9FAF7'),
 'professional': dict(bg1='#14213D', bg2='#25407A', accent='#D0A94E', accent2='#8FAEE0', paper='#F7F6F2', wash='#ECEAE2', ink='#13203A', muted='#58627A', on='#EEF2FB'),
 'fitness':  dict(bg1='#14121F', bg2='#33245C', accent='#C8F23C', accent2='#8A6BFF', paper='#F6F6F9', wash='#E9E8F2', ink='#15131F', muted='#5E5C72', on='#F1F0FA'),
 'outdoors': dict(bg1='#12301F', bg2='#245B3A', accent='#E6B53F', accent2='#86BC7F', paper='#F6F5EB', wash='#E8EDDC', ink='#14241A', muted='#556559', on='#EEF4E8'),
 'retail':   dict(bg1='#1C2644', bg2='#3A4F8C', accent='#FF7E5C', accent2='#FFCB5C', paper='#FBF8F5', wash='#F1ECE6', ink='#1A2138', muted='#5E6580', on='#F1F4FD'),
 'default':  dict(bg1='#12263A', bg2='#1F5A6E', accent='#F2B84B', accent2='#52B7C4', paper='#F5F8F9', wash='#E4EEF0', ink='#122230', muted='#52646E', on='#EAF5F7'),
}

KEYWORDS = [
 ('food', 'restaurant cafe coffee bakery bistro grill pizza taco bbq catering kitchen diner eatery deli brewery bar pub sushi donut ice cream food truck'),
 ('beauty', 'salon spa nail wax lash barber hair beauty skin massage tattoo aesthetic brow makeup'),
 ('trades', 'plumb hvac air condition roof electric contractor construction paving pest lawn pressure wash auto repair mechanic towing garage tire collision locksmith cleaning maid handyman remodel pool painting flooring'),
 ('medical', 'dental dentist clinic chiropractic medical doctor physician therapy therapist counsel vet veterinary animal hospital optometr urgent care pediatric wellness health'),
 ('professional', 'law attorney legal accounting cpa tax insurance real estate realty realtor consult financial advis mortgage bookkeep notary title'),
 ('fitness', 'gym fitness yoga pilates crossfit martial arts karate dance studio training boxing cycle'),
 ('outdoors', 'nursery garden landscap farm ranch equine horse stable riding feed pet kennel grooming tree outdoor boarding'),
 ('retail', 'boutique gift shop store florist furniture jewel clothing apparel antique thrift market flowers'),
]


def pick_archetype(text):
    t = ' ' + text.lower() + ' '
    best, score = 'default', 0
    for arch, words in KEYWORDS:
        s = sum(1 for w in words.split() if (' ' + w) in t or w in t and len(w) > 5)
        if s > score:
            best, score = arch, s
    return best


def _rng(seed):
    return random.Random(seed)


def hero_art(seed):
    r = _rng(seed)
    out = ['<svg class="art" viewBox="0 0 560 560" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">']
    out.append('<defs><linearGradient id="hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>')
    cx, cy = r.randint(300, 440), r.randint(110, 190)
    out.append(f'<circle cx="{cx}" cy="{cy}" r="{r.randint(70,96)}" style="fill:var(--accent)" opacity=".9"/>')
    out.append(f'<circle cx="{cx}" cy="{cy}" r="{r.randint(120,150)}" style="fill:var(--accent)" opacity=".18"/>')
    for i in range(5):
        y = 250 + i * 62 + r.randint(-10, 10)
        amp = r.randint(22, 52)
        p = r.randint(0, 120)
        d = f'M-20 {y} C {120+p} {y-amp}, {240-p} {y+amp}, {360+p//2} {y-amp//2} S 560 {y+amp//2}, 600 {y}'
        d += ' L 600 620 L -20 620 Z'
        op = .20 + i * .13
        col = 'var(--bg2)' if i % 2 == 0 else 'var(--bg1)'
        if i == 2:
            col = 'var(--accent2)'
        out.append(f'<path d="{d}" style="fill:{col}" opacity="{min(op,.92):.2f}"/>')
    for _ in range(14):
        x, y, s = r.randint(30, 530), r.randint(40, 300), r.randint(2, 5)
        out.append(f'<circle cx="{x}" cy="{y}" r="{s}" fill="#fff" opacity="{r.uniform(.3,.8):.2f}"/>')
    out.append('<rect width="560" height="560" fill="url(#hg)" opacity=".5"/></svg>')
    return ''.join(out)


def about_art(seed):
    r = _rng(seed + 7)
    out = ['<svg viewBox="0 0 500 400" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">']
    for i in range(6):
        rad = 60 + i * 52
        out.append(f'<circle cx="{r.randint(120,380)}" cy="{r.randint(100,300)}" r="{rad}" style="fill:var(--{"accent" if i%2 else "accent2"})" opacity="{.10+i*.04:.2f}"/>')
    for i in range(4):
        x = r.randint(-20, 380)
        w = r.randint(80, 160)
        out.append(f'<rect x="{x}" y="{200+i*30}" width="{w}" height="14" rx="7" style="fill:var(--bg1)" opacity="{.10+i*.05:.2f}" transform="rotate(-14 {x} 300)"/>')
    out.append('<path d="M0 330 C 120 280, 220 360, 330 310 S 470 290, 500 320 L500 400 L0 400Z" style="fill:var(--bg1)" opacity=".78"/>')
    out.append('<path d="M0 365 C 140 330, 260 395, 380 350 S 480 345, 500 360 L500 400 L0 400Z" style="fill:var(--bg2)" opacity=".9"/>')
    out.append('</svg>')
    return ''.join(out)


def map_art(seed):
    r = _rng(seed + 13)
    out = ['<svg viewBox="0 0 600 420" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">']
    for i in range(1, 9):
        x = i * 70 + r.randint(-14, 14)
        out.append(f'<path d="M{x} 0 L{x+r.randint(-40,40)} 420" stroke="#fff" stroke-width="{r.choice([6,10,14])}" opacity=".85" fill="none"/>')
    for i in range(1, 6):
        y = i * 72 + r.randint(-12, 12)
        out.append(f'<path d="M0 {y} L600 {y+r.randint(-40,40)}" stroke="#fff" stroke-width="{r.choice([6,10,14])}" opacity=".85" fill="none"/>')
    for _ in range(9):
        out.append(f'<rect x="{r.randint(10,540)}" y="{r.randint(10,360)}" width="{r.randint(26,70)}" height="{r.randint(22,52)}" rx="8" style="fill:var(--accent2)" opacity=".16"/>')
    out.append('<path d="M-10 330 C 140 260, 260 380, 410 310 S 580 300, 620 330" stroke="var(--accent2)" stroke-width="26" opacity=".25" fill="none" stroke-linecap="round"/>')
    out.append('</svg>')
    return ''.join(out)


def product_art(seed):
    r = _rng(seed)
    cols = ['accent', 'accent2', 'bg2']
    out = ['<svg viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">']
    out.append(f'<rect width="400" height="260" style="fill:var(--wash)"/>')
    out.append(f'<circle cx="{r.randint(120,280)}" cy="{r.randint(90,150)}" r="{r.randint(70,100)}" style="fill:var(--{r.choice(cols)})" opacity=".55"/>')
    out.append(f'<circle cx="{r.randint(60,340)}" cy="{r.randint(40,200)}" r="{r.randint(30,60)}" style="fill:var(--{r.choice(cols)})" opacity=".45"/>')
    out.append(f'<rect x="{r.randint(110,170)}" y="{r.randint(60,100)}" width="{r.randint(90,130)}" height="{r.randint(90,120)}" rx="22" style="fill:var(--bg1)" opacity=".85" transform="rotate({r.randint(-12,12)} 200 130)"/>')
    out.append('<rect width="400" height="260" fill="#fff" opacity=".08"/></svg>')
    return ''.join(out)
